import { Component, OnInit } from '@angular/core';
import {MatDialog , MatDialogConfig, MatDialogRef} from '@angular/material/dialog';
import { UploadExcelComponent } from '../upload-excel/upload-excel.component';
@Component({
  selector: 'app-generate-pass',
  templateUrl: './generate-pass.component.html',
  styleUrls: ['./generate-pass.component.css']
})
export class GeneratePassComponent implements OnInit {

  constructor(private dialog:MatDialog,private dialogRef: MatDialogRef<GeneratePassComponent>) { }

  ngOnInit(): void {
  }

  closeDialog(){
    this.dialogRef.close();
  }

  bulkData(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '70%';
    dialogConfig.height = '50%';
   
    const dialogRef = this.dialog.open(UploadExcelComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
    });
    this.dialogRef.close();
  }

}
